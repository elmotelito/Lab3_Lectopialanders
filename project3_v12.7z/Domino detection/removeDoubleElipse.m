
function [hola2]=removeDoubleElipse(hola2)
%ASUME that only 2 elipses are in one domino
X=hola2.Location;
X_x=X(:,1);
X_y=X(:,2);
threshold=625;
helpCon=1;
for iu=1:length(X)
    dist_sq = (X_x-X_x(iu)).^2+(X_y-X_y(iu)).^2;
    [dist_sq_sort, dist_sq_index]=sort(dist_sq);
     too_close=dist_sq_sort<threshold;
     toocloseindex=find(too_close);
    index=dist_sq_index(toocloseindex);
    %assume there is only 2 repetead elipses close to each other
    if length(index)==2
        axiss(helpCon,:)=index;
        helpCon=helpCon+1;
    elseif length(index)==1
        axiss=[];
    end
    c_circles{iu}=sort(index)';
end


%Asume there is only 2 repeated elipses per domino
erase = unique(axiss);
indice = 1;
while indice <length(erase)
    if length(hola2) ==(erase(end)-1)
    compareAxis = hola2((erase(indice:indice+1,:))-1).Axes;  %ADD COUNTER THAT SUBSTRACT TO THE LAST ELEMENT
        if compareAxis(1)>compareAxis(2)
            hola2(erase(indice)-1)=[];
        else
            hola2(erase(indice))=[];
        end
    else
    compareAxis = hola2(erase(indice:indice+1,:)).Axes;
        if compareAxis(1)>compareAxis(2)
            hola2(erase(indice))=[];
        else
            hola2(erase(indice+1))=[];
        end
    end
    indice=indice+2;
    compareAxis=[];
end

% 
% FINAL=0;
% indexNew=1;
% while indexNew < length(c_circles)
%     FINAL=FINAL+1
%     indexNew=indexNew+length(c_circles{indexNew});
% end

end
