%%
%Establish the Origin from the Picture taken by the camera
%Ox = pixel in X at origin (can be top corner)
%Oy= pixel in Y at origin (that form the top corner)
%Px= location of Ox in Real World wrt Robot Base

%Py= location of Oy in Real World wrt Robot Base
[B,C]=fidumask(I); %Figure should be rgb, original foto taken
[DE,FG]=detectMSERFeatures(rgb2gray(C));
kl=0;
Fidu=[];
for i=1:length(DE);
    if((DE.Location(i)<755 && DE.Location(i)>415)&&(DE.Location(i,2)<50))
        kl=kl+1;
        Fidu(kl,1)=DE.Location(i,1);
        Fidu(kl,2)=DE.Location(i,2);
    end
end
if length(Fidu)>1
    Centroid=mean(Fidu);
else 
    Centroid=Fidu;
end
Ox=Centroid(1,1);
Oy=Centroid(1,2);
%%
Domi=dominoCentroid;
Domi=sortrows(Domi);
angles= zeros(length(Domi), 2); %Domi is the matrix containing the locations of the centroids
for i=1:length(Domi)
    dx=(Domi(i,1)-Ox);
    dy=(Domi(i,2)-Oy);
    dx_cm=dx/25; %distance in pixels converted to cm
    dy_cm=dy/25;
    yoffset=9.4; %Yoffset from the base to the Fiducial
    distx=dx_cm;
    disty=dy_cm+yoffset;
    if(dx_cm<0)
        angles(i,1)=((atand(abs(disty)/abs(distx)))+6)*3.41;  %--+-+-+-+-+% cambie el angulo, estaba +6
        %display('joha');
    else
        angles(i,1)=((180-atand(abs(disty)/abs(distx)))+6)*3.41; %-+-+-+-+--% cambie el angulo, estaba +6
        %display('jppd');
    end 
    angles(i,2)=sqrt(distx^2+disty^2)-1;
end    

