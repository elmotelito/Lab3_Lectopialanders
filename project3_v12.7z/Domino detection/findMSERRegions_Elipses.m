function [ matr,Orientation,hola2 ] = findMSERRegions_Elipses( im_edges)
%This function receives a gray image that has been cropped and where edges
%have been detected previously
%The aim of this function is to determine how many dominos there are in the
%scene, using MSERRegions. Elipses will be drawn around each domino

%%
% Detect MSER regions.
I = im_edges;
[regions,mserCC] = detectMSERFeatures1(I,'RegionAreaRange',[5500 10000]);
%'RegionAreaRange',[800 5000]  ---> perfect for lista

% Show all detected MSER Regions.
% figure
% imshow(I)
% hold on
% plot(regions,'showPixelList',false,'showEllipses',true)


%%
% Measure the MSER region eccentricity to gauge region circularity.
%Eccentricity 
%   returns ratio of distance between the foci of the ellipse and its major axis length. The value is between 0 and 1. 
%(0 and 1 are degenerate cases. An ellipse whose eccentricity is 0 is actually a circle, while an ellipse whose eccentricity is 1 is a line 
%'EquivDiameter'
%   Returns a scalar that specifies the diameter of a circle with the same area as the region. 
stats = regionprops('table',mserCC,'Area','Eccentricity','Centroid','BoundingBox', 'Image','Orientation','MinorAxisLength','MajorAxisLength');

%% EXAMPLE FOR VARIOUS CONDITIONS
% cc = bwconncomp(I);
% idx = find([stats.Area] > 900 & [stats.Eccentricity] > 0.5); 
% BW2 = ismember(labelmatrix(cc), idx);

%%
% Threshold eccentricity values to only keep the circular regions.
% (Circular regions have low eccentricity.) Major WAS 195, leter 218
hola= stats.MajorAxisLength >145 & stats.MajorAxisLength<173 & stats.MinorAxisLength<90 & stats.MinorAxisLength>69; %200
%only lines
%hola= stats.MajorAxisLength >40 & stats.MajorAxisLength<70 & stats.MinorAxisLength<20 & stats.Eccentricity>0.9; %200
hola2 = regions(hola);

p=1;
[~,ord] = sort([hola2.Location(:,1)]);
    hola2 = hola2(ord);
    
    %0.45 - 0.55
while (p<=length(hola2)-1)
    %Try comparing the euclidean distance from one centroid to the other
%     X = hola2.Location;
%     D = pdist(X,'euclidean');
%     dist=squareform(D);
      
    %
    R = hola2(p).Location;
    S = hola2(p+1).Location;
    X = [R(1) R(2) S(1) S(2)];
    
    if ((abs(R(1)-S(1))<60) && (abs(R(2)-S(2))<60))
        Q = hola2(p).Axes;
        QQ = hola2(p+1).Axes;
        %------------------------
%         ratioQ = Q(2)/Q(1);
%         ratioQQ = QQ(2)/QQ(1);
%         if ratioQ>0.45 & ratioQ<0.65
%             hola2(p+1)=[];
%         elseif ratioQQ>0.45 & ratioQQ<0.65
%            hola2(p+1)=[];
%         end
        %-------------------------
        if  Q(1)<QQ(1)
            hola2(p+1)=[];
        else
            hola2(p)=[];
        end
        p=p-1;
            
    end
    p=p+1;
   %     if a==1
%         p=p-1;
%         a=0;
%     end
end
    
% close all

[~,ord] = sort([hola2.Location(:,2)]);
    hola2 = hola2(ord);
p=1;
while (p<=length(hola2)-1)
    
    R = hola2(p).Location;
    S = hola2(p+1).Location;
    X = [R(1) R(2) S(1) S(2)];
    
    if ((abs(R(1)-S(1))<60) && (abs(R(2)-S(2))<60))
        Q = hola2(p).Axes;
        QQ = hola2(p+1).Axes;
        if  Q(1)<QQ(1)
            hola2(p+1)=[];
        else
            hola2(p)=[];
        end
        p=p-1;
            
    end
    p=p+1;
   %     if a==1
%         p=p-1;
%         a=0;
%     end
end
    
% Show all detected MSER Regions.
% figure
% imshow(I)
% hold on
% plot(hola2,'showPixelList',true,'showEllipses',true)
    
for i=1:length(hola2)
    Location = hola2(i).Location;
        Axes = hola2(i).Axes;
        Orientation(i)=hola2(i).Orientation;  
    if hola2(i).Orientation>0
        param = [Location(1), Location(2), Axes(2), Axes(1), (pi/2)-Orientation(i)]; 
    end 
    if hola2(i).Orientation<0
        if hola2(i).Orientation<1
            param = [Location(1), Location(2), Axes(2), Axes(1),-(Orientation(i)-pi/2)];
        else
            param = [Location(1), Location(2), Axes(2), Axes(1),Orientation(i)];      
        end
    end
    %imshow(I);
%     hold on
    [h,Xpos,Ypos]=DrawRectangle_v6(param);
    matr(i,:) = [Xpos,Ypos];  
%     rectangle
%     plot(hola2)
%     hold on
end

if length(hola2)==0
     matr=[];
     Orientation=[];
     hola2=[];
end
%draw_rect_on_original(I2,matr, Orientation);

end

