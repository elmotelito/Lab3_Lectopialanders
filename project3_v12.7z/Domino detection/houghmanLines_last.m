function [lines]=houghmanLines_last(image2)
% se = strel('rectangle',[2 2]);
I3  = image2;
% imshow(I);
%hold on
% I = immultiply(I,0.5);
% I = imsharpen(I);
% I = rgb2gray(I);
% I = imerode(I,se);
% I = imdilate(I,se);
% I = edge(I,'canny',0.15);
% I = 1-I;
% I = imgaussfilt(I,2);
% I = imsharpen(I);
%% - -------- Other method
% I = imerode(I,se);
% I = imsharpen(I);
% I = rgb2gray(I);
% I = edge(I,'canny',0.2);
% I = imerode(1-I,se);
%I3 = showlines(I3);
%I3 = rgb2gray(I3);

% h=fspecial('unsharp');
% I = imfilter(I,h);
% 
% I=imfilter(I,ones(5)/25);

% I= imadjust(I);
% I = imsharpen(I);
% I=imadjust(I);
% I = imdilate(I,se);


%I = imadjust(I);

rotI = imrotate(I3,0,'crop');
BW = edge(rotI,'canny');
[H,T,R] = hough(BW);
%imshow(H,[],'XData',T,'YData',R,...
          %  'InitialMagnification','fit');
%xlabel('\theta'), ylabel('\rho');
%axis on, axis normal, hold on;
P  = houghpeaks(H,5,'threshold',ceil(0.3*max(H(:))));
x = T(P(:,2)); y = R(P(:,1));
%plot(x,y,'s','color','white');
lines = houghlines(BW,T,R,P,'FillGap',25,'MinLength',5);
%figure ;imshow(rotI), hold on
max_len = 10;
for k = 1:length(lines)
   xy = [lines(k).point1; lines(k).point2];
   % plot(xy(:,1),xy(:,2),'LineWidth',2,'Color','green');

   % Plot beginnings and ends of lines
   % plot(xy(1,1),xy(1,2),'x','LineWidth',2,'Color','yellow');
   % plot(xy(2,1),xy(2,2),'x','LineWidth',2,'Color','red');

   % Determine the endpoints of the longest line segment
   len = norm(lines(k).point1 - lines(k).point2);
   if ( len > max_len)
      max_len = len;
      xy_long = xy;
   end
end
end 