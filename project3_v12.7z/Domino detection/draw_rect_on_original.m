function [lines,vector] = draw_rect_on_original( OrgImage , matrix,Orientation,I2)
%This function draws a rectangule around each domino
%
close all
%imshow(I2);

recta={};
nume=1;
lines={};
Orientation=Orientation;
%imshow(OrgImage);
%hold on;

% 5 functions 
matr=matrix;
% figure();
% title('Detected dominos in workspace')
% imshow(OrgImage);
% hold on
for num=1:length(matr(:,1))
    x = [matr(num,1:5)];
    y = [matr(num,6:10)];
    %plot(x, y, 'b-', 'LineWidth', 3);
    xx=sort(x);
    yy=sort(y);
    xlow=xx(1);
    xhigh=xx(length(x));
    ylow=yy(1);
    yhigh=yy(length(y));
    recta{nume}=[xlow ylow xhigh-xlow yhigh-ylow];
    nume=nume+1;
end 

for domino=1:length(recta)
    rect=round(recta{domino});
    image=imcrop(OrgImage,rect);  %For lines (edges)
    image123=imcrop(I2,rect);     %For circles(colour)
    %imwrite(image123,'jojo.jpg')
    %figure
    %imshow(image)
       
    if (Orientation(domino))<0;%%-----------------------------
     image = flipdim(image ,2);   %% CREATED THIS 

    end                        %%-----------------------------
    %%image22 = rgb2gray(image);  This was done for circles below
    %imwrite(image123,sprintf('try%d.jpg',domino));
    %figure(); imshow(image);  %%COMENTED THIS
    
   
    
    %At this point we have a single image which will be analyse to
    %determine whether there are circles inside it  
    
    %% Check lines
    lines{domino}=houghmanLines_last(image);
    vector(domino)=detectLines4_Last(lines, domino,image,matrix,image123);
    %% ------------------------------------------------
    %%Draw the lines that correspond to the domino 
     
%     [number_circles,flag] = detect_circles(image123);   
%     
    
end

end

