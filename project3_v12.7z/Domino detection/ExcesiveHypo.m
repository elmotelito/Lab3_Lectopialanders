if data(dominoNum,3)<29
    %Move Domino + do stuff
else
    msgbox('Please Move the Domino Inside the Workspace');
    pause(10);
    %Place Domino + do stuff here
end