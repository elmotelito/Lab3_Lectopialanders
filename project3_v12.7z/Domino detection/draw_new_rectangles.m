function [new_matr] = draw_new_rectangles(hola2)
for i=1:length(hola2)
    Location = hola2(i).Location;
        Axes = hola2(i).Axes;
        Orientation(i)=hola2(i).Orientation;  
    if hola2(i).Orientation>0
        param = [Location(1), Location(2), Axes(2), Axes(1), (pi/2)-Orientation(i)]; 
    end 
    if hola2(i).Orientation<0
        if hola2(i).Orientation<1
            param = [Location(1), Location(2), Axes(2), Axes(1),-(Orientation(i)-pi/2)];
        else
            param = [Location(1), Location(2), Axes(2), Axes(1),Orientation(i)];      
        end
    end
    %imshow(I);
    hold on
    [h,Xpos,Ypos]=DrawRectangle_v6(param);
    new_matr(i,:) = [Xpos,Ypos];  
%     rectangle
    plot(hola2)
    hold on
end