%% Final code for sorting dominoes 
%%Infor about the code

%% Initialize motor arm
loadlibrary('dynamixel.dll', 'dynamixel.h');
libfunctions('dynamixel');
DEFAULT_PORTNUM = 5;
DEFAULT_BAUDNUM = 1;
calllib('dynamixel', 'dxl_initialize', DEFAULT_PORTNUM, DEFAULT_BAUDNUM);
calllib('dynamixel','dxl_write_word',1,32,60); %%Set speed for motor 1
calllib('dynamixel','dxl_write_word',2,32,30);
calllib('dynamixel','dxl_write_word',3,32,30);
calllib('dynamixel','dxl_write_word',4,32,20);
dominoNum=1;
end_program=0;

%% Start the program

%% ASK THE USER IF HE/SHE WANTS TO START
ButtonName = questdlg('Do you want to start?', ...
                     'Start Lab 3 Demo', ...
                     'Yes', 'No','Yes');
 switch ButtonName,
    case 'Yes',
        msgbox('LECTOPIALANDERS will start sorting for you');
        pause(2)
        close all 
                                   
        %% Initial position
        initial_position();
        load('angles_plane.mat');

        %% TAKE A PHOTO
        %WEBCAM
        cam=webcam(1);
        cam.Resolution='1280x720';
        pause(2)
        I=snapshot(cam);
        figure();imshow(I)
        imwrite(I,'joha1Lib.jpg');%WEBCAM
        %% DETECTION
        %Matrix containing the data that has to be sent to the motors
        %This matrix is 4xNumOfDominosFound where
        % data = [NumCircles motor1_steps distance(cm) endEffec_steps]
        data = dominoDetectionRecognition2(I,cameraParams);
        %close all
        %% ROBOT ARM (PICK DOMINO AND SORTED IN THE RIGHT POSITION)
            %pick domino
            % pick_domino(angle,distance,rotation);
            [nuevo1,beta,theta_total] = pick_domino(data(dominoNum,2),data(dominoNum,3),data(dominoNum,4));
            %end_effector(data(ii,2));

            %WAIT!!!!!
            pause(3);
         %% Move to initial position
            bring_domino(data(dominoNum,3),height,beta,data(dominoNum,2),theta_total);

            %% Move to sorting position
            angles_circles(data(dominoNum,1),angles_plane);

            
        %% Repeat for all dominoes 
 while (1)
             %% Take picture and detect for next domino
    I=snapshot(cam);
    figure();imshow(I)
    imwrite(I,'joha1Lib.jpg');%WEBCAM
    data = dominoDetectionRecognition2(I,cameraParams);
    
    if data(dominoNum,3)<28
        [nuevo1,beta,theta_total] = pick_domino(data(dominoNum,2),data(dominoNum,3),data(dominoNum,4));
        pause(3);
        bring_domino(data(dominoNum,3),height,beta,data(dominoNum,2),theta_total);
        angles_circles(data(dominoNum,1),angles_plane);
        if length(data(:,1))==2 
            end_program = end_program+1; 
            if end_program ==2
                close all
                 msgbox('Thanks METR4202 Staff! Kind regards');
                    break;
            end 
            ButtonName = questdlg('Do you want to continue sorting?', ...
                             'Sort More Dominos', ...
                             'Yes', 'No','Yes');
             switch ButtonName,
                case 'Yes',
                    msgbox('You Have Decided to Continue Sorting');
                    pause(2)
                    I=snapshot(cam);
                    figure();imshow(I)
                    imwrite(I,'joha1Lib.jpg');%WEBCAM
                    data = dominoDetectionRecognition2(I,cameraParams);
                case 'No',
                    msgbox('Thanks METR4202 Staff! Kind regards');
                    break; 
              end
        end 
    
  
    else
    
        ButtonName = questdlg('Please move the domino into the workspace', ...
                     'Warning', ...
                     'OK','No');
                switch ButtonName,
                case 'OK',
                    I=snapshot(cam);
                    figure();imshow(I)
                    imwrite(I,'joha1Lib.jpg');%WEBCAM
                    data = dominoDetectionRecognition2(I,cameraParams);
    
                end
    end 
 end 
                    
    case 'No',
     msgbox('Thanks METR4202 Staff! Kind regards');
     end
    

