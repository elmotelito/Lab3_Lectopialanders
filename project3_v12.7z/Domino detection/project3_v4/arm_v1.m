%% Initialize 
loadlibrary('dynamixel.dll', 'dynamixel.h');
libfunctions('dynamixel');
DEFAULT_PORTNUM = 4;
DEFAULT_BAUDNUM = 1;
calllib('dynamixel', 'dxl_initialize', DEFAULT_PORTNUM, DEFAULT_BAUDNUM);
calllib('dynamixel','dxl_write_word',1,32,60); %%Set speed for motor 1
calllib('dynamixel','dxl_write_word',2,32,30);
calllib('dynamixel','dxl_write_word',3,32,30);
calllib('dynamixel','dxl_write_word',4,32,20);


%% Initial position for sorting
initial_position();

%range 200 to 460 at low speed

%% pick domino
pick_domino(angle,distance); 
end_effector(angle)


%% Move to radius 2
radius2(angle_from_base);

%% Move to radius 3
radius3(angle_from_base);

%% Terminate
calllib('dynamixel','dxl_terminate');
unloadlibrary('dynamixel');


