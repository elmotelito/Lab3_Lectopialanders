function [] = angles_circles(circles_detected,angles_plane)
%%Uses the information of the circles of the domino
%%to place the domino on the first or second row
 information = angles_plane(circles_detected+1,:);
 angle_to_move = information(1);
 radius_to_move = information(2);
 rearrange = circshift(information,[-1 -2]);
 angles_plane(circles_detected+1,:) = rearrange;
 assignin('base','angles_plane',angles_plane)
 
if radius_to_move == 2
    radius3(angle_to_move);
elseif radius_to_move == 3
    radius3(angle_to_move);
else
end 
  
end