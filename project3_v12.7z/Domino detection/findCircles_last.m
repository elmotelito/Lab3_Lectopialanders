function [centersBright] = findCircles_last(image);
 %se = strel('disk',1);
close all
 rgb = image;
% [BW,rgb]=createMask_yellow(rgb);
imshow(rgb);
hold on
rgb = image(:,:,3);
rgb=cat(3, rgb,rgb,rgb);
rgb = imsharpen(rgb);
%rgb=showlines(rgb);
rgb = imsharpen(rgb);
% rgb = imsharpen(rgb);
% %rgb2 = imsharpen(rgb2);
% %rgb2 = imerode(rgb2,se);
% figure
% imshow(rgb);

 %rgb(:,:,3) = 255;   Try this
%rgb = histeq(rgb2gray(rgb));
    
%rgb = rgb2ycbcr(rgb);
% I = adapthisteq(rgb);
%rgb = decorrstretch(rgb);




% rgb = rgb2gray(rgb);
% rgb = imadjust(rgb);
% rgb = imadjust(rgb);
% imshow(rgb)
%imshow(image3)


% imshow(rgb)
% d = imdistline;
% delete(d);
% gray_image = rgb;
% imshow(gray_image);
% [centers, radii] = imfindcircles(rgb,[10 30],'ObjectPolarity','dark', ...
%     'Sensitivity',0.93)
% imshow(rgb);
% 
% h = viscircles(centers,radii);
% [centers, radii] = imfindcircles(rgb,[10 30],'ObjectPolarity','dark', ...
%     'Sensitivity',0.92);
% 
% length(centers)
% delete(h);  % Delete previously drawn circles
% h = viscircles(centers,radii);
% [centers, radii] = imfindcircles(rgb,[10 30], 'ObjectPolarity','bright', ...
%           'Sensitivity',0.92,'Method','twostage');
% 
% delete(h);
% 
% h = viscircles(centers,radii);
% [centers, radii] = imfindcircles(rgb,[3 10], 'ObjectPolarity','dark', ...
%           'Sensitivity',0.92);
% % 
% % delete(h);
% % 
% viscircles(centers,radii);
% imshow(gray_image);
% [centersBright, radiiBright] = imfindcircles(rgb,[10 30],'ObjectPolarity', ...
%     'dark','Sensitivity',0.92);
 %imshow(rgb);

[centersBright, radiiBright, metricBright] = imfindcircles(BW,[2 6], ...
    'ObjectPolarity','dark','Sensitivity',0.90);
hBright = viscircles(centersBright, radiiBright,'Color','b');
hold on
  end 
 