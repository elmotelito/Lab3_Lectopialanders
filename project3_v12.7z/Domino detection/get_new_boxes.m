function [number_circles,flag] = get_new_boxes(new_matr,I2);
recta={};
nume=1;
matr=new_matr;
imshow(I2);
hold on
for num=1:length(matr(:,1))
    x = [matr(num,1:5)];
    y = [matr(num,6:10)];
    plot(x, y, 'b-', 'LineWidth', 3);
    xx=sort(x);
    yy=sort(y);
    xlow=xx(1);
    xhigh=xx(length(x));
    ylow=yy(1);
    yhigh=yy(length(y));
    recta{nume}=[xlow ylow xhigh-xlow yhigh-ylow];
    nume=nume+1;
end 

for domino=1:length(recta)
    rect=round(recta{domino});
    image123=imcrop(I2,rect);
    size12 = size(image123);
    image123 = imcrop(image123,[10 10 size12(2)-15 size12(1)-15]);
      %figure
    %imshow(image)
                          %%-----------------------------
    %%image22 = rgb2gray(image);  This was done for circles below
    imwrite(image123,sprintf('try%d.jpg',domino));
    figure(); imshow(image123);  %%COMENTED THIS
    
%     circles=detect_circles(image);   %%image22 was for this
%     if length(circles)==0
%         display('nooooooo domino')
%     else
%         display('domino')
%     end
    
    
    %At this point we have a single image which will be analyse to
    %determine whether there are circles inside it  
    
    %% Check lines
     %% ------------------------------------------------
    %%Draw the lines that correspond to the domino 
    [number_circles,flag] = detect_circles(image123);    
    
    
end
end 