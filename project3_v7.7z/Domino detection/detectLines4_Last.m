function [vector] = detectLines4_Last(lines,domino,image2,matrix,image123)
lines=lines;
posi=domino;
image2=image2;
ros=1;
ros1=1;
T = struct2table(lines{posi});
T = sortrows(T, 'rho', 'ascend');
sizeT = size(T);
sizeT = sizeT(1);
theta=T{:,{'theta'}};
rho1=T{:,{'rho'}};
abc=1;
ros4=1;
% while ros4 < (sizeT)
%     pnt1 = T(ros4,1);
%     pnt1 = pnt1{1,:};
%     pnt2 = T(ros4,2);
%     pnt2 = pnt2{1,:};
%     min_dist = [pnt1(1),pnt1(2);pnt2(1),pnt2(2)];
%     dist = pdist(min_dist,'euclidean')
%     if dist<70 
%        T((ros4),:)=[];
%        ros4=ros4-1;        
%     end
%     sizeT = size(T);
%     sizeT = sizeT(1);
%     ros4=ros4+1;
% end

while ros <(sizeT)
    while abc<=sizeT 
        theta=T{:,{'theta'}};
        rho1=T{:,{'rho'}};
        if theta(abc)<0 && rho1(abc)<0
             T(abc,:)=[];
             abc=abc-1;          
        end 
        sizeT = size(T);
        sizeT = sizeT(1);
        abc=abc+1;
    end
    
    %
    if sizeT ~=0
        theta=T{:,{'theta'}};
        rho1=T{:,{'rho'}};
        variable = size(T);
        if variable(1)==1
           T(2,:) = T(1,:); 
            theta=T{:,{'theta'}};
            rho1=T{:,{'rho'}};
        end 
        if abs(theta(ros)-theta(ros+1))<6 && abs(rho1(ros)-rho1(ros+1))<10
           T((ros+1),:)=[];
           ros=ros-1;        
        end
        sizeT = size(T);
        sizeT = sizeT(1);
        ros=ros+1;
    end
end 
T = sortrows(T, 'rho', 'ascend');

while ros1 < (sizeT)
    rho=T{:,{'rho'}};
%     theta1 = T{:,{'theta'}};
    if abs(rho(ros1)-rho(ros1+1))<30 
       T((ros1+1),:)=[];
       ros1=ros1-1;        
    end
    sizeT = size(T);
    sizeT = sizeT(1);
    ros1=ros1+1;
end 
ros3=1;
while ros3<sizeT
    theta=T{:,{'theta'}};
    if abs(theta(ros3)-theta(ros3+1))>10
        
        T((ros3+1),:)=[];
        ros3=ros3-1;
    end
     sizeT = size(T);
    sizeT = sizeT(1);
    ros3=ros3+1;
        
    
end

 sizeT = size(T);
 sizeT = sizeT(1);
 ros2=1;
 %figure
 %imshow(image2);
 %----------------
 %%
 
 %--------------
 blanco = check_bw1(image123)
 
 %499 and 277 and 294 and 395, 84, 198
 if  sizeT>1 && blanco>5500
     true_rec=1;
 else
     [numCircles1,flag,circularRegions] = detect_circles(image123);
     if numCircles1>0 && blanco>2500                 %JOHA CHANGED THIS FOR WEBCAM
         true_rec=1;
     else
     %%Check if it is white to make true_rec = 1; 
%      isdomino=check_bw(image123);
%      if isdomino==1
%         true_rec=1;
%      else
         true_rec=0;
     end 
     
 end 
     
 
 vector = true_rec;
 
 %%
 if sizeT>1  %Find middle point only if we get more than two line matching description 
     true_rec=1;
     for abc=1:sizeT
         
         point1= T(abc,1);
         point1=point1{1,:};
         point2= T(abc,2);
         point2=point2{1,:};
         middlex(abc) = (point1(1)+point2(1))/2;
         middley(abc)= (point1(2)+point2(2))/2;
         
         
    %    eval(['middlex' num2str(abc) ' = middlex;'])
    %    eval(['middley' num2str(abc) ' = middley;'])

     end
  
 for abc=1:sizeT
     point1= T(abc,1);
     point1=point1{1,:};
     point2= T(abc,2);
     point2=point2{1,:};
     middlex(abc) = (point1(1)+point2(1))/2;
     middley(abc)= (point1(2)+point2(2))/2;
% hold on
% plot([point1(1) point2(1)],[point1(2) point2(2)],'linewidth',3)
% plot(middlex(1),middley(1),'*');
% plot(middlex(2),middley(2),'*');
% plot([middlex(1) middlex(2)],[middley(1) middley(2)],'linewidth',3);
middleLine = [middlex(1),middley(1);middlex(2),middley(2)];
distance =  pdist(middleLine,'euclidean');

 end

 end 
 

end