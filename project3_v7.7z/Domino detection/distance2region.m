dist_sq=(X-X(feature_no)).^2+(Y-Y(feature_no)).^2;
[dist_sq_sort, dist_sq_index]=sort(dist_sq);
too_close=dist_sq_sort<threshold;
toocloseindex=find(too_close);
dist_sq_index(toocloseindex)

%non maximal suppression
%doc peaks
c_circles={};
counterC=0;
threshold=5;
finalIndex=[];
X=hola2.Location; %FIRST ELIPSE 
X_x=X(:,1);
X_y=X(:,2);
for iu=1:length(X)
    dist_sq = (X_x-X_x(iu)).^2+(X_y-X_y(iu)).^2;
    [dist_sq_sort, dist_sq_index]=sort(dist_sq);
     too_close=dist_sq_sort<threshold;
     toocloseindex=find(too_close);
    index=dist_sq_index(toocloseindex);
    c_circles{iu}=sort(index)';
       
end

FINAL=0;
indexNew=1;
while indexNew < length(c_circles)
    FINAL=FINAL+1;
    indexNew=indexNew+length(c_circles{indexNew});
end



length(too_close)

