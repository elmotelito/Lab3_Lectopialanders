function [theta_total,beta] = inverse_kinematics(hypotenuse,height)
arm1 = 18;
arm2=11.4;
end_effector = 14.5; %14.5 originally
%height_base = 8.5; %11.2
height_base = height;
y = end_effector-height_base;
y=y+1; %% to balance errors hehe 
if hypotenuse <=19
   y=y-1; 
end
theta = atan2(y,hypotenuse)*180/pi;
distance = sqrt(hypotenuse^2+y^2);

%%angle alpha
alpha = ((arm1^2+distance^2-arm2^2)/(2*arm1*distance));
alpha = acos(alpha)*180/pi;
%%angle beta
beta  = (arm1^2+arm2^2-distance^2)/(2*arm1*arm2);
beta = (180-(acos(beta)*180/pi))*3.41; % 3.41 is the number of steps for 1 degree

theta_total = (90-(theta+alpha))*3.41;  %3.41 is the number of steps for 1 degree;

end 

