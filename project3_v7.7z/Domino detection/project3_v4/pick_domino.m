function [pos_end,beta] = pick_domino(angle,distance,rotation) %%NOTA--- a�adi el beta para poder mover el brazo al final mas arriba %%
if distance <= 15
    height = 11;
end 
if distance>15 && distance <= 21
    height = 10;
end 
if distance>21 && distance <= 23
    height = 9;
end 
if distance>23 && distance <= 25
    height = 8.5;
end 
if distance>25
    height = 8;
end 
assignin('base','height',height)
calllib('dynamixel','dxl_write_word',1,32,80);
calllib('dynamixel','dxl_write_word',2,32,30);
calllib('dynamixel','dxl_write_word',3,32,40);
calllib('dynamixel','dxl_write_word',4,32,20);
angle=507+angle;
calllib('dynamixel','dxl_write_word',2,30,270);
pause(2)
calllib('dynamixel','dxl_write_word',3,30,450);
calllib('dynamixel','dxl_write_word',1,30,angle);
pause(2)
a=calllib('dynamixel','dxl_read_word',1,36);
pos_end = end_effector(angle);
while ~(a<=angle+3 && a>=angle-3)
    a=calllib('dynamixel','dxl_read_word',1,36);
end
pause(0.3)
if rotation>0
    if (pos_end-rotation)<0
        pos_end = pos_end+2047.5;
         calllib('dynamixel','dxl_write_word',4,30,pos_end-rotation);
    else 
        calllib('dynamixel','dxl_write_word',4,30,pos_end-rotation);
    end
end
if rotation<0
    if (pos_end+abs(rotation))>4095
        pos_end = pos_end-2047.5;
        calllib('dynamixel','dxl_write_word',4,30,pos_end+abs(rotation));
    else
        calllib('dynamixel','dxl_write_word',4,30,pos_end+abs(rotation));
    end
end
pause(0.6)
[theta_total,beta]=inverse_kinematics(distance,height);
calllib('dynamixel','dxl_write_word',3,32,25); %% velocity (wasnt here)
calllib('dynamixel','dxl_write_word',3,30,200+beta-8); %% the 5 is just to balance the end effector(might need to be removed)
b=calllib('dynamixel','dxl_read_word',3,36);
pause(0.5)
while ~(b <= (200+beta-8+3) && b>= (200+beta-8-3))
   b=calllib('dynamixel','dxl_read_word',3,36);
end
pause(0.5)
calllib('dynamixel','dxl_write_word',2,32,15); %was 20
calllib('dynamixel','dxl_write_word',2,30,200+theta_total+15);
c=calllib('dynamixel','dxl_read_word',2,36);
pause(0.5)
while c<=~((200+theta_total+10+5) && c>=(200+theta_total+10-5))
   c=calllib('dynamixel','dxl_read_word',2,36);
end
%this is for moving u and down pause(2)
% calllib('dynamixel','dxl_write_word',2,30,200+theta_total+10-20);
% pause(1)
% calllib('dynamixel','dxl_write_word',2,30,200+theta_total+10);
pause(0.8)

end 