function [] = bring_domino(distance1,height,beta,angle)
%%Brings the domino to a specific position to then move it to
%%the place of interest
calllib('dynamixel','dxl_write_word',4,30,3352);
pause(2)
calllib('dynamixel','dxl_write_word',1,32,30);
calllib('dynamixel','dxl_write_word',1,30,600);
a=calllib('dynamixel','dxl_read_word',1,36);
while ~(a<=600+5 && a>=600-5)
    a=calllib('dynamixel','dxl_read_word',1,36);
end
pause(1) 
calllib('dynamixel','dxl_write_word',3,30,200+beta-8-20); %%NOTA-- a�adi esto 
if angle <=300
   calllib('dynamixel','dxl_write_word',3,30,200+beta-8-40); 
   display('hola')
end 
pause(1.5)%% la pausa estaba 1
%end_effector(700)
calllib('dynamixel','dxl_write_word',4,30,4052);
pause(2);
% a=calllib('dynamixel','dxl_read_word',4,36);
% display('aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa')
% while ~(a<=4052+5 && a>=4052-5)
%     a=calllib('dynamixel','dxl_read_word',4,36);
%     
% end

for distance1 = distance1:-0.1:10  %% -0.1
   [a,b] = inverse_kinematics(distance1,height);
   calllib('dynamixel','dxl_write_word',2,30,200+a+15);
   calllib('dynamixel','dxl_write_word',3,30,200+b);
   pause(0.1) %%--- 0.1
end
pause(0.2)

calllib('dynamixel','dxl_write_word',1,30,600);
pause(0.2)
calllib('dynamixel','dxl_write_word',3,30,657); % 661 originally 
calllib('dynamixel','dxl_write_word',2,30,320); %325 originally
pause(0.2)
calllib('dynamixel','dxl_write_word',4,30,3150);
% a=calllib('dynamixel','dxl_read_word',4,36);
% while ~(a<=3060+5 && a>=3060-5)
%     a=calllib('dynamixel','dxl_read_word',4,36);
% end
pause(2)

end
