
%Find frame in world when a tutor placed the frame anywhere they want
%assume the camara parameters were obtained beforehand

%Run after the calibration.
%Get the camera parameters
%addpath('calibrationPhotos')

colorVid=videoinput('kinect',1,'BGR_1920x1080');

%Get photo with the frame in the corner of the workspace
OrgFrame = getsnapshot(colorVid);imshow(OrgFrame);

%Get new photo with frame somewhere else and 
newFrame = getsnapshot(colorVid);imshow(newFrame);
imwrite(newFrame,'frame.jpg')

%Load the LAST picture of calibration
%OrgFrame = imread('image25.jpg');
%OR TAKE A NEW PHOTO WITH THE CENTRAL FRAME AT THE CORNER-------!!!!


%% Get the  Extrinsics for the last picture of calibration
%[cameraParams,worldPoints] = get_cam_parameters();

%%Undistort, homography and crop 
%-------------CHECK VALUES -----------------
I1 = undistort_homo_crop (newFrame, cam);  %new photo
I2 = undistort_homo_crop (OrgFrame, cam);  %Original position


%% Find the frame in the new photo
% Jonathan's function

[CMx,CMy]=find_frame_tutor(I1, I2);
C = [CMx,CMy];

save('FrameCentroids.mat','C');


% fid = fopen('MasterCentroids.txt','w')
% fprintf(fid,'%d\n',boardSize);
% fclose(fid);
% type 'calibrationData.txt'


% %Calculate the distance of the camara to the world frame
% hmenor=sqrt(46^2+10^2);
% zNew=sqrt(T(3)^2-hmenor^2);
% dist=sqrt(T(1)^2+(T(2)-46)^2+zNew^2);

