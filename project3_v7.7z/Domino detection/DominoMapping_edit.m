function [] = dominoMap (matrix, Cmx, Cmy)

%Code to Find Distances from Each Domino's Centroid to Master Centroid CMx,
%CMy.
%Assume we get a matrix DominoCentroids of size nx2, CMx and CMy. Where CMx
%is Master Centroid X and CMy is Master Centroid Y.

S=size(matrix);
distances=zeros(1,S(1));
angles=zeros(1,S(1));
for k=1:S(1)
    cx=matrix(k,1);
    cy=matrix(k,2);
    PixCm= 0.026458333;
    dix=CMx-cx; dixcm=dix*PixCm;
    diy=CMy-cy; diycm=diy*PixCm;
    distance=sqrt(dixcm^2+diycm^2);
    distances(k)=single(distance);%distance in cm
    diy= -1*diy;
    x=(diycm/dixcm);
    
    if(dix>0)
        angle=atand(x);
    elseif(dix<0) && (diy>=0)
        angle= atand(x)+180;
    elseif (dix<0)&&(diy<0)
        angle=atand(x)-180;
    elseif (dix==0)&&(diy>0)
        angle=90;
    elseif (dix==0)&&(diy<0)
        angle=-90;
    else
        angle=0;
    end
    angles(k)=single(angle);
    Position=fprintf('Position of Domino %d from arbitrary centroid is: %.2f cm, %.2f� \n',...
        [k distances(k) angles(k)]);
    %Position
    
end


