close all
ims = I;
figure;
imshow(ims);
P = ginput(4)';
%P=[115, 500, 620, 72;215, 200, 410, 415];
X = [min(P(1,:)), min(P(2,:)); 
     max(P(1,:)), min(P(2,:)); 
     max(P(1,:)), max(P(2,:)); 
     min(P(1,:)), max(P(2,:))]';
H = homography(P, X);
final = homwarp(H, ims);
output=final;
%output = imcrop(final,[100 400 740 560]);

imwrite(output, 'output.jpg');
figure();
imshow(output);


