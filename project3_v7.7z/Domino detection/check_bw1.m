function [blanco]=check_bw1(image)
%Assume the image is a cropped rgb picture of an object that may be a
%domino
I=image;
A2=rgb2gray(I);
A3=imbinarize(A2,0.7);%imshow(A3)
blanco = sum(A3(:));
end