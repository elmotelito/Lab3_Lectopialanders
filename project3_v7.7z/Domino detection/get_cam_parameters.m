function [cam,worldPoints] = get_cam_parameters()
%This function calculates the intrinsics from a set of pictures taken
%during the autocalibration4. The parameters of the camera are calculated 
%and send as output. These parameters are used to undistort images.
%Call this function as follows
%   [cameraParams,worldPoints] = get_cam_parameters();

%EXAMPLE - Undistort images
% last_image = imread('croppedNueva1.jpg');
% im = undistortImage(last_image, cameraParams);
% imshow(im)

%------------START-----------
 imageFileNames ={};
% %Perform calibration at the beggining of the script using the images
% %created in the initial calibration (i.e. ImageFileNames)

addpath('calibrationPhotos');
% %Get the image's names
for i=1:25
    b=sprintf('image%d.jpg', i);
    imageFileNames{i}=b;
end

% Detect calibration pattern.
[imagePoints, boardSize] = detectCheckerboardPoints(imageFileNames);

% Generate the world coordinates of the checkerboard corners in the pattern-centric coordinate system, with the upper-left corner at (0,0).
squareSize = 26; % in millimeters
worldPoints = generateCheckerboardPoints(boardSize, squareSize);
 
% Calibrate the camera.
cam = estimateCameraParameters(imagePoints, worldPoints, ...
    'EstimateSkew', false, 'EstimateTangentialDistortion', false, ...
    'NumRadialDistortionCoefficients', 2, 'WorldUnits', 'mm', ...
    'InitialIntrinsicMatrix', [], 'InitialRadialDistortion', []);

% %Load the LAST picture of calibration
% last_image = imread('image25.jpg');
% 
% % Undistort image.
% im = undistortImage(last_image, cameraParams);
% 
% % Find reference object in new image.
% [imagePoints1, boardSize1] = detectCheckerboardPoints(im);
% 
% % Compute new extrinsics.
% [rotationMatrix, translationVector] = extrinsics(imagePoints1, worldPoints, cameraParams);
% 
% % -------------------------------------------
% 
% % %matrix is a matrix containing the focal length and the intrinsics
% % matrix=dlmread('calibrationData.txt');
% % %We separate the region of interest from the main matrix
% % M=matrix(2:4,1:3);
end

