%Retriebe the exact domino number
function [UpNumber, LowNumber]= dominoNum(nuevamatr, OrientAngle,Imagen_original)
A=size(nuevamatr);
nume=1;
for num=1:length(nuevamatr(:,1))
    x = [nuevamatr(num,1:5)];
    y = [nuevamatr(num,6:10)];
    plot(x, y, 'b-', 'LineWidth', 3);
    xx=sort(x);
    yy=sort(y);
    xlow=xx(1);
    xhigh=xx(length(x));
    ylow=yy(1);
    yhigh=yy(length(y));
    recta{nume}=[xlow ylow xhigh-xlow yhigh-ylow];
    nume=nume+1;
end 
for i=1:A(1)
    rect=round(recta{i});
    image=imcrop(Imagen_original,rect);  %For lines (edges)
    %figure; imshow(image);
RotIm=imrotate(image, -OrientAngle(i));
S=size(RotIm);
Height= S(1); Width= S(2);
Upper= imcrop(RotIm, [1 1 Width Height/2]);
Lower= imcrop(RotIm, [1 Height/2 Width Height/2]);
% figure; imshow(Upper);
% figure; imshow(Lower);
[numCirclesUpper,flag,circularRegionsUpper]=detect_circles(Upper);
[numCirclesLower,flag,circularRegionsLower]=detect_circles(Lower);

p=1;
[~,ord] = sort([circularRegionsUpper.Location(:,1)]);
    circularRegionsUpper = circularRegionsUpper(ord);
    
while (p<=length(circularRegionsUpper)-1)
    
    R = circularRegionsUpper(p).Location;
    S = circularRegionsUpper(p+1).Location;
    X = [R(1) R(2) S(1) S(2)];
    
    if ((abs(R(1)-S(1))<8) && (abs(R(2)-S(2))<8))
        Q = circularRegionsUpper(p).Axes;
        QQ = circularRegionsUpper(p+1).Axes;
        if  Q(2)>QQ(2)
            circularRegionsUpper(p+1)=[];
        else
            circularRegionsUpper(p)=[];
        end
        p=p-1;
            
    end
    p=p+1;
   %     if a==1
%         p=p-1;
%         a=0;
%     end
end
    
%close all

[~,ord] = sort([circularRegionsUpper.Location(:,2)]);
    circularRegionsUpper = circularRegionsUpper(ord);
p=1;
while (p<=length(circularRegionsUpper)-1)
    
    R = circularRegionsUpper(p).Location;
    S = circularRegionsUpper(p+1).Location;
    X = [R(1) R(2) S(1) S(2)];
    
    if ((abs(R(1)-S(1))<8) && (abs(R(2)-S(2))<8))
        Q = circularRegionsUpper(p).Axes;
        QQ = circularRegionsUpper(p+1).Axes;
        if  Q(2)>QQ(2)
            circularRegionsUpper(p+1)=[];
        else
            circularRegionsUpper(p)=[];
        end
        p=p-1;
            
    end
    p=p+1;
   %     if a==1
%         p=p-1;
%         a=0;
%     end
end

%% For lower 
p=1;
[~,ord] = sort([circularRegionsLower.Location(:,1)]);
    circularRegionsLower = circularRegionsLower(ord);
    
while (p<=length(circularRegionsLower)-1)
    
    R = circularRegionsLower(p).Location;
    S = circularRegionsLower(p+1).Location;
    X = [R(1) R(2) S(1) S(2)];
    
    if ((abs(R(1)-S(1))<8) && (abs(R(2)-S(2))<8))
        Q = circularRegionsLower(p).Axes;
        QQ = circularRegionsLower(p+1).Axes;
        if  Q(2)>QQ(2)
            circularRegionsLower(p+1)=[];
        else
            circularRegionsLower(p)=[];
        end
        p=p-1;
            
    end
    p=p+1;
   %     if a==1
%         p=p-1;
%         a=0;
%     end
end
    
%close all

[~,ord] = sort([circularRegionsLower.Location(:,2)]);
    circularRegionsLower = circularRegionsLower(ord);
p=1;
while (p<=length(circularRegionsLower)-1)
    
    R = circularRegionsLower(p).Location;
    S = circularRegionsLower(p+1).Location;
    X = [R(1) R(2) S(1) S(2)];
    
    if ((abs(R(1)-S(1))<8) && (abs(R(2)-S(2))<8))
        Q = circularRegionsLower(p).Axes;
        QQ = circularRegionsLower(p+1).Axes;
        if  Q(2)>QQ(2)
            circularRegionsLower(p+1)=[];
        else
            circularRegionsLower(p)=[];
        end
        p=p-1;
            
    end
    p=p+1;
   %     if a==1
%         p=p-1;
%         a=0;
%     end
end


%% --
UpNumber(i)=length(circularRegionsUpper);
LowNumber(i)=length(circularRegionsLower);
%figure; imshow(image);
% viscircles(Upcenters, Upradii);
% viscircles(Lowcenters, Lowradii);
fprintf('The Domino Number is %d/%d\n',[UpNumber(i), LowNumber(i)]);
end



