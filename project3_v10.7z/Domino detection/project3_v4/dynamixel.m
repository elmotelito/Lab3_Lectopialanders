clear all
loadlibrary('dynamixel.dll', 'dynamixel.h');
libfunctions('dynamixel');
DEFAULT_PORTNUM = 4;
DEFAULT_BAUDNUM = 1;

calllib('dynamixel', 'dxl_initialize', DEFAULT_PORTNUM, DEFAULT_BAUDNUM);
calllib('dynamixel','dxl_write_word',1,32,5);
calllib('dynamixel','dxl_write_word',2,32,20);
calllib('dynamixel','dxl_write_word',3,32,20);
calllib('dynamixel','dxl_write_word',4,32,20);  %range for base, starting at 2000, go to 0 to sort and 3500 to turntable
calllib('dynamixel','dxl_write_word',1,30,0);
calllib('dynamixel','dxl_write_word',2,30,205); %range 200 to 460 at low speed
calllib('dynamixel','dxl_write_word',3,30,661);   %Starts at 200 goes to 600 (low speed to 650)
calllib('dynamixel','dxl_write_word',4,30,798);
pause (4)
calllib('dynamixel','dxl_write_word',1,30,800);
calllib('dynamixel','dxl_write_word',2,30,470);
calllib('dynamixel','dxl_write_word',3,30,500);
pause(4)
calllib('dynamixel','dxl_write_word',1,30,500);
calllib('dynamixel','dxl_write_word',2,30,200);
calllib('dynamixel','dxl_write_word',3,30,200);
calllib('dynamixel','dxl_terminate');
unloadlibrary('dynamixel');