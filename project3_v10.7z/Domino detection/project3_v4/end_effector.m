function [pos_end] = end_effector(angle_base)
%%This function moves the end effector such that its x axis
%%paraller to the x axis of the camera

if angle_base<=650
    %% for base 650
    calllib('dynamixel','dxl_write_word',4,30,2580);
    pos_end = 2580;
elseif angle_base>650 && angle_base<=660
%% 650-660
calllib('dynamixel','dxl_write_word',4,30,2550);
pos_end = 2550;
elseif angle_base>660 && angle_base<=670
%% 660-670
 calllib('dynamixel','dxl_write_word',4,30,2600);
 pos_end = 2600;
 elseif angle_base>670 && angle_base<=680
 %% 670-680
 calllib('dynamixel','dxl_write_word',4,30,2610);
 pos_end = 2610;
 elseif angle_base>680 && angle_base<=690
%% 680-690
 calllib('dynamixel','dxl_write_word',4,30,2690);
 pos_end = 2690;
  elseif angle_base>690 && angle_base<=700
%% 690-700
 calllib('dynamixel','dxl_write_word',4,30,2700);
 pos_end = 2700;
 elseif angle_base>700 && angle_base<=710
%% 700-710
 calllib('dynamixel','dxl_write_word',4,30,2750);
 pos_end = 2750;
 elseif angle_base>710 && angle_base<=720
 %% 710-720
 calllib('dynamixel','dxl_write_word',4,30,2770);
 pos_end = 2770;
 elseif angle_base>720 && angle_base<=730
 %% 720-730
 calllib('dynamixel','dxl_write_word',4,30,2800);
 pos_end = 2800;
 elseif angle_base>720 && angle_base<=740
 %% 730-740
 calllib('dynamixel','dxl_write_word',4,30,2835);
 pos_end = 2835;
 elseif angle_base>740 && angle_base<=750
 %% 740-750
calllib('dynamixel','dxl_write_word',4,30,2860);
pos_end = 2860;
elseif angle_base>750 && angle_base<=760
%% 750-760
calllib('dynamixel','dxl_write_word',4,30,2900);
pos_end = 2900;
elseif angle_base>760 && angle_base<=770
%% 760-770
calllib('dynamixel','dxl_write_word',4,30,2920);
pos_end = 2920;
elseif angle_base>770 && angle_base<=780
%% 770-780
calllib('dynamixel','dxl_write_word',4,30,2950);
pos_end = 2950;
elseif angle_base>780 && angle_base<=790
%% 780-790
calllib('dynamixel','dxl_write_word',4,30,2990);
pos_end = 2990;
elseif angle_base>790 && angle_base<=800
%% 790-800
calllib('dynamixel','dxl_write_word',4,30,3015);
pos_end = 3015;
elseif angle_base>800 && angle_base<=810
%% 800-810
calllib('dynamixel','dxl_write_word',4,30,3030);
pos_end = 3030;
elseif angle_base>810 && angle_base<=820
%% 810-820
calllib('dynamixel','dxl_write_word',4,30,3070);
pos_end = 3070;
elseif angle_base>820 && angle_base<=830
%% 820-830
calllib('dynamixel','dxl_write_word',4,30,3100);
pos_end = 3100;
elseif angle_base>830 && angle_base<=840
%% 830-840
calllib('dynamixel','dxl_write_word',4,30,3130);
pos_end = 3130;
elseif angle_base>840 && angle_base<=850
%% 840-850
calllib('dynamixel','dxl_write_word',4,30,3185);
pos_end = 3250;
elseif angle_base>850 && angle_base<=860
%% 850-860
calllib('dynamixel','dxl_write_word',4,30,3210);
pos_end = 3210;
elseif angle_base>860 && angle_base<=870
%% 860-870
calllib('dynamixel','dxl_write_word',4,30,3250);
pos_end = 3250;
elseif angle_base>870 && angle_base<=880
%% 870-880
calllib('dynamixel','dxl_write_word',4,30,3280);
pos_end = 3280;
elseif angle_base>880 && angle_base<=890
%% 880-890
calllib('dynamixel','dxl_write_word',4,30,3310);
pos_end = 3310;
elseif angle_base>890 && angle_base<=900
%% 890-900
calllib('dynamixel','dxl_write_word',4,30,3325);
pos_end = 3325;
elseif angle_base>900 && angle_base<=910
%% 900-910
calllib('dynamixel','dxl_write_word',4,30,3380);
pos_end = 3380;
elseif angle_base>910 && angle_base<=920
%% 910-920
calllib('dynamixel','dxl_write_word',4,30,3415);
pos_end = 3415;
elseif angle_base>920 && angle_base<=930
%% 920-930
calllib('dynamixel','dxl_write_word',4,30,3450);
pos_end = 3450;
elseif angle_base>930 && angle_base<=940
%% 930-940
calllib('dynamixel','dxl_write_word',4,30,3480);
pos_end = 3480;
elseif angle_base>940 && angle_base<=950
%% 940-950
calllib('dynamixel','dxl_write_word',4,30,3510);
pos_end = 3510;
elseif angle_base>950 && angle_base<=960
%% 950-960
calllib('dynamixel','dxl_write_word',4,30,3550);
pos_end = 3550;
elseif angle_base>960 && angle_base<=970
%% 960-970
calllib('dynamixel','dxl_write_word',4,30,3580);
pos_end = 3580;
elseif angle_base>970 && angle_base<=980
%% 970-980
calllib('dynamixel','dxl_write_word',4,30,3610);
pos_end = 3610;
elseif angle_base>980 && angle_base<=990
%% 980-990
calllib('dynamixel','dxl_write_word',4,30,3660);
pos_end = 3660;
elseif angle_base>990 && angle_base<=1000
%% 990-1000
calllib('dynamixel','dxl_write_word',4,30,3700);
pos_end = 3700;
elseif angle_base>1000 && angle_base<=1010
%% 1000-1010
calllib('dynamixel','dxl_write_word',4,30,3730);
pos_end = 3730;
end 
