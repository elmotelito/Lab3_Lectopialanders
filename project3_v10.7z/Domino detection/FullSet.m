%Full set ??

% colorVid=videoinput('kinect',1,'BGR_1920x1080');
% 
% %Get a photo from the scene
% I = getsnapshot(colorVid);
% imName=sprintf('properset.jpg')
% imwrite(I,imName);imshow(I)

%%for now
I=imread('fullsetNop.jpg');

%%
%Undistort and crop with different numbers
I2=undistort_homo_crop_full(I,cam);

%%
im_edges=edge_detection(I2);
figure();
imshow(im_edges);

%%
%Detect MSERfeatures and draw elipses around dominos
[matrix,Orientation,hola2] = findMSERRegions_Elipses_FullSet(im_edges);
%FindCircularMSERRegionsExample
%Daniel code is detect_dominos2
%saveas(gca,'old.jpg');
%old = imread('old.jpg');

%%
%%Create a new gray image for a single domino, and analyse the circles
%%inside them (Actually detects which has parallel lines)
[lines,vector] = draw_rect_on_original(im_edges,matrix,Orientation,I2);


%% Get New ellipses
new_pos=1;
posi1=1;
imshow(im_edges);
hold on;
while new_pos<=length(hola2)
    if vector(posi1)==0;
        hola2(new_pos)=[];
        new_pos=new_pos-1;
          
    end
     posi1=posi1+1;
    new_pos=new_pos+1;
end 

%% Draw New Rectangles
%figure
%imshow(im_edges);
%hold on
new_matr= draw_new_rectangles(hola2);
saveas(gca,'new.jpg');
new = imread('new.jpg');   
%% Crop Only dominos
 close all
 %[number_circles,flag]=get_new_boxes(new_matr,I2);
%imshowpair(old,new,'montage')
%% Detect circles
%imshow(I2)
%title('LECTOPIALANDERS');
%hold on
%[numCircles,flag,circularRegions]=detect_circles(I2);
%plot(hola2);
[Xpos11,Ypos11] = draw_final_rectangles(hola2);
close all
%% ggg
% final_circles = findCircles_inside(circularRegions,Xpos11,Ypos11);
% 
% for cir = 1:length(hola2)
%     xx=double((Xpos11(cir,1)));
%     yy=double((Ypos11(cir,1)));
%     str = num2str(final_circles(cir));
%      text(xx,yy,str,'FontSize',20)   
% end 

imshow(I2)
title('LECTOPIALANDERS');
hold on
plot(hola2);

%%Check how many dominos do we have?

    if length(hola2) >= 28
        fprintf('There is 28 dominos on the table');
        fprintf('\nThis is a complete set');
    else 
        fprintf('There is %.d dominos on the table',length(hola2)-2);
        fprintf('\nThis is NOT a complete set');
    end

