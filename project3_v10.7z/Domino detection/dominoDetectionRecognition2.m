function [ infoMotor ] = dominoDetectionRecognition2 (I,cameraParams)

%DOMINO DETECTION 
tic;

%WEBCAM
% cam=webcam(1);
% cam.Resolution='1280x720';    %%JOHA MOVED THIS OUTSIDE THE FUNCTION  
% I=snapshot(cam);
% figure();imshow(I)
% imwrite(I,'joha1Lib.jpg');

%% colorVid=videoinput('kinect',1,'BGR_1920x1080');
% 
% Get a photo from the scene
% I = getsnapshot(colorVid);
% imName=sprintf('scene1.jpg')
% imwrite(I,imName);

%% saved photoso because I can't use camera, for general
%   %delete this andli uncomment above
%    I = imread('johatry.jpg');
%    figure()
%    imshow(I)
%%
%Run a quick calibration to get the camera parameters 
%[cam,worldPoints] = get_cam_parameters();

I2 = undistortImage(I, cameraParams);
%figure();imshow(I2)


%%
%Apply EDGE DETECTION
%%Daniel code for edge detection edgesDemo_v3
%The input should be an rgb image (cropped)
% im_edges=edge_detection(I);
% figure();
% imshow(im_edges);
im_edges=rgb2gray(I2);
%%
%Detect MSERfeatures and draw elipses around dominos
[matrix,Orientation,hola2] = findMSERRegions_Elipses(im_edges);
%FindCircularMSERRegionsExample
%Daniel code is detect_dominos2
% saveas(gca,'old.jpg');
% old = imread('old.jpg');


%%
%%Create a new gray image for a single domino, and analyse the circles
%%inside them (Actually detects which has parallel lines)
[lines,vector] = draw_rect_on_original(im_edges,matrix,Orientation,I);


%% Get New ellipses
new_pos=1;
posi1=1;
%imshow(im_edges);
%hold on;
while new_pos<=length(hola2)
    if vector(posi1)==0;
        hola2(new_pos)=[];
        new_pos=new_pos-1;
          
    end
     posi1=posi1+1;
    new_pos=new_pos+1;
end 

%% Draw New Rectangles
% figure
% imshow(im_edges);
% hold on
new_matr= draw_new_rectangles(hola2);
% saveas(gca,'new.jpg');
% new = imread('new.jpg');   

%% Crop Only dominos
close all
 
 %ASSUME THAT WE have two elipses in the same place
 hola2 = removeDoubleElipse(hola2);
 
 %[number_circles,flag]=get_new_boxes(new_matr,I2);
%imshowpair(old,new,'montage')
%% Detect circles
close all;
figure();
imshow(I)
title('LECTOPIALANDERS');
hold on
[numCircles,flag,circularRegions]=detect_circles(I);
plot(hola2);
plot(circularRegions);
[Xpos11,Ypos11] = draw_final_rectangles(hola2); %contains information of the rectangles
%% ggg
[final_circles,newCircles] = findCircles_inside(circularRegions,Xpos11,Ypos11);
for cir = 1:length(hola2)
    xx=double((Xpos11(cir,1)));
    yy=double((Ypos11(cir,1)));
    str = num2str(newCircles(cir));
     text(xx,yy,str,'FontSize',16)
    %str2 = num2str(newCircles(cir));
     %text(xx,yy,str2,'FontSize',14,'Color','r')
end 

%% You can start mapping from here now 
%CREATE A STRUCTURE -> FOR EACH DOMINO
% 
dominoCentroidandOrientation=zeros(length(hola2),3);
dominoCentroidandOrientation = [hola2.Location hola2.Orientation*(180/pi)];
dominoID=zeros(length(hola2),1);
dominoID(:,1) = newCircles';
% dominoID(:,2) = hola2.Orientation*(180/pi);

%domino MATRIX
%domino = [cx cy ID Orientation]
domino=[dominoCentroidandOrientation dominoID];
domino=sortrows(domino); %SORTED BY X

%% INFO FOR THE MOTORS !!!!
%GET the number of steps to send to the motors
angles = get_steps_Motor1(I,domino(:,1:2)); %STEPS and distance
endEffectorSteps = (domino(:,3)*11.375); %STEPS

anglesEndEffector = domino(:,3); %in order to check the angle of the elipse wrt 
%infoMotor = [ID motor1_steps distance(cm) endEffec_steps]
infoMotor = [domino(:,4) angles endEffectorSteps];

toc;

end
