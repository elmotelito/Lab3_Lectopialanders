function [ final ] = homograph_v3( undistorted )
%homograph rectifies image and then crops the resulting image.
%   distorted(matrix of rgb image)-> homo(jpg) 

%im=imresize(undistorted, [1080 1920]);
%imwrite(im, 'img.jpg');
%figure;
%imshow(undistorted);
P=[180, 770, 865, 80;40, 30, 400, 390]; %(x y) pixels for each corner
%P=[600, 650, 1550, 1600;360, 400, 900, 910];
X = [min(P(1,:)), min(P(2,:)); 
     max(P(1,:)), min(P(2,:)); 
     max(P(1,:)), max(P(2,:)); 
     min(P(1,:)), max(P(2,:))]';
H = homography(P, X);
final = homwarp(H, undistorted);
%final=imresize(final, [1080 1920]);
%figure();
%imshow(final);
% I2 = imcrop(final,[625 400 510 390]); %[xmin ymin width height]
% homo=imresize(I2, [1080 1920]);
% imwrite(homo, 'homo.jpg');
% a=imread('homo.jpg');
% a=imresize(a, [1080 1920]);
% imwrite(a, 'homographed.jpg');
% figure;
% imshow(imread('homographed.jpg'));
end

