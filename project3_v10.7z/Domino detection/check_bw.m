function [isdomino]=check_bw (image)
%Assume the image is a cropped rgb picture of an object that may be a
%domino
I=image;
A2=rgb2gray(I);
A3=imbinarize(A2);
figure();imshow(A3);
isdomino=0;

%a=[]; %The Binarized Logical Image of Interest
black=0;
white=0;
A=size(A3);
for i=1:A(1)
    %Rows
    %i
    for ii=1:A(2)
     %   ii
        %Columns
        if A3(i,ii)==1
            white=white+1;
        else 
            black=black+1;
        end
    end
end
black=black/A(2);
white=white/A(1);
r=black/white;
if(r<=1)
    String='It IS a Domino';
    display(String);
    isdomino=1;
else
    String='It is NOT a domino';
    display(String);
    isdomino=0;
end
end