%Autocalibration 4
%Calibration performed using a checkboard with a square size of 26mm
%This script aims to write the results from the calibration into a text
%file for future use

%Create a folder and add it to the path
mkdir('calibrationPhotos')
addpath('calibrationPhotos')

% info=imaqhwinfo('kinect');
% info.DeviceInfo(1)
% colorVid=videoinput('kinect',1,'BGR_1920x1080');

i=1;
imageFileNames ={};
%Create an object to hold the information of the color camera
% colorVid=videoinput('kinect',1,'BGR_1920x1080');

%Get the frame at the corner
% frame = getsnapshot(colorVid);
% imwrite(frame,'OriginalFrame.jpg');
%%

for i=1:25
    camImage =snapshot(cam); %Takes a picture
    b=sprintf('image%d.jpg', i)
    imwrite(camImage,b); %Create a jpg image
    movefile(b,'calibrationPhotos');
    imageFileNames{i}=b;
    pause(1);
end

% for i=1:25
%     b=sprintf('image%d.jpg', i);
%     imageFileNames{i}=b;
% end

%%
% Detect checkerboards in images
addpath('calibrationPhotos');

[imagePoints, boardSize, imagesUsed] = detectCheckerboardPoints(imageFileNames);
imageFileNames = imageFileNames(imagesUsed);

% Generate world coordinates of the corners of the squares
squareSize = 26;  % in units of 'mm'
worldPoints = generateCheckerboardPoints(boardSize, squareSize);

%%Calibrate the camera
%cameraParams = estimateCameraParameters(imagePoints, worldPoints);
[cameraParams, imagesUsed, estimationErrors] = estimateCameraParameters(imagePoints, worldPoints, ...
    'EstimateSkew', false, 'EstimateTangentialDistortion', false, ...
    'NumRadialDistortionCoefficients', 2, 'WorldUnits', 'mm', ...
    'InitialIntrinsicMatrix', [], 'InitialRadialDistortion', []);


%%
Intrinsics=cameraParams.IntrinsicMatrix;


%% Display results
sprintf('Skew = %d', cameraParams.Skew)
display(Intrinsics);

% View reprojection errors
h1=figure; showReprojectionErrors(cameraParams, 'BarGraph');
title('Reprojection Errors');

%Visualize pattern locations
h2=figure; showExtrinsics(cameraParams, 'CameraCentric');

%Display parameter estimation errors
displayErrors(estimationErrors, cameraParams);

%% Calculate Extrinsics for the frame placed by ourselves
%As a result, consider the last photo from calibration.
%[ I,rotationMatrix, translationVector] = get_intrin_exint_matrix( cameraParams , worldPoints );

