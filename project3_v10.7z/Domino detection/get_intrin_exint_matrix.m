function [ I,rotationMatrix, translationVector] = get_intrin_exint_matrix( cameraParams , worldPoints )
% This function will compute the intrinsics and extrinsics of the RGB
% camera, provided that calibration was performed beforehand, and the
% photos are saved in a folder
% The Intrisic matrix is defined as I
%The EXTRINSICS are calculated for the last frame (i.e photo) in the
%calibration photos folder, which is required to be align with the central
%frame in the work space. The extrinsics are described as a rotation matrix
%R and a translation vector T. Therefore, matrix P = [R T']

%Additionally, cameraParams will be used in the future to Undistort images
%Call this function as follows
%   [Intri, R, T] = get_intrin_exint_matrix(cameraParams , worldPoints);


%Get instrinsics
I = cameraParams.IntrinsicMatrix;

%Load the LAST picture of calibration
last_image = imread('image25.jpg');

% Undistort image.
im = undistortImage(last_image, cameraParams);

% Find reference object in new image.
[imagePoints, boardSize] = detectCheckerboardPoints(im);

% Compute new extrinsics.
[rotationMatrix, translationVector] = extrinsics(imagePoints, worldPoints, cameraParams);

% %Calculate the distance of the camara to the world frame
hmenor=sqrt(46^2+10^2);
zNew=sqrt(translationVector(3)^2-hmenor^2);
fprintf('The central Frame is located %.2f cm from camera',zNew);
dist=sqrt(translationVector(1)^2+(translationVector(2)-46)^2+zNew^2);
%ASSUMING THE TOP LEFT CORNER OF THE CHECKERBOARD WAS DETECTED 174
%46 mm

%Extrinsics
fprintf('The Translation vector from camera to frame is:');
display(translationVector)

end

