%assume an unsorted matrix of Centers;
%Starting with the first x,y coordinate. 
%assume a Matrix of Centers mx2, m circles in total with each row having x
%and y coordinates.
Circles=sortrows(mo,1);
Final_Circles= [];
i=1;
while i<length(Circles)
    initialx= Circles(i,1);
    initialy= Circles(i,2);
    if((abs(Circles(i+1,1)-initialx)<=5)&&(abs(Circles(i+1,2)-initialy)<=5))
        Circles(i+1,1)=initialx;
        Circles(i+1,2)=initialy;
        Final_Circles(i,1)=Circles(i,1);
        Final_Circles(i,2)=Circles(i,2);
        
    end
    i=i+1;
end
k=length(Circles);
while k>1
    initx= Circles(k,1);
    inity= Circles(k,2);
    Final_Circles(k+1,1)=initx;
    Final_Circles(k+1,2)=inity;
    if((abs(Circles(k-1,1)-initx)<=5)&&(abs(Circles(k-1,2)-inity)<=5))
%         Circles(k-1,1)=initx;
%         Circles(k-1,2)=inity;
        Final_Circles(k-1,1)=initx;
        Final_Circles(k-1,2)=inity;
        k=k-1;
    end
    k=k-1;
end
%Refilter Final_Circles
Final_Circles=sortrows(Final_Circles,1);
Ultimate=[];
m=1;
l=1;
 while l<length(Final_Circles)
     P1=Final_Circles(l,:);
     P2=Final_Circles(l+1,:);
     C=minus(P2,P1);
     if ((P2(1)~=0)&&((C(1)~=0)&&C(1)>10))
         Ultimate(m,1)=P2(1);
         Ultimate(m,2)=P2(2);
         m=m+1;
     end
     l=l+1;
 end 
    
    
    

