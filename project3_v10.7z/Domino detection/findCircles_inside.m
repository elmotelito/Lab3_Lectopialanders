function [final_circles,newCircles] = findCircles_inside(circularRegions,Xpos11,Ypos11)

%sort by x?
% [~,ord] = sort([circularRegions.Location(:,1)]);
%     circularRegions = circularRegions(ord);
%--------------
%Look for how many circles are there inside a rectangle
circles = circularRegions.Location;

xposition = circles(:,1);
yposition = circles(:,2);
cont=1;
joha={};
for abcd=1:length(Xpos11(:,1))
    new_pos=1;
    posi1=1;
    squarex = Xpos11(abcd,:);
    squarey = Ypos11(abcd,:);
    xv = squarex(1:5);
    xv = transpose(xv);
    yv = squarey(1:5);
    yv = transpose(yv);
    [in,on] = inpolygon(xposition,yposition,xv,yv);
    
    %------------------------------------CHANGED BY JOHA
    %At this point we know how many circles are there inside a single
    %domino
    %get the x,y coordinates of every circle inside a domino
    an=xposition&in;
    indices=find(an>=1);
    jo=circularRegions(indices).Location;
    joha{cont}=jo;
    cont=cont+1;
    %-------------------------------------------
    
    %TOTAL NUMBER OF CIRCLES INSIDE A DOMINO
    final_circles(abcd)=numel(xposition(in)); 
    
end 

%------------------------------------CHANGED BY JOHA
c_circles={};
%counterC=0;
threshold=13; %25
%finalIndex=[];

for kit=1:length(joha)
    %Loop for every domino to look for how many circles are there?
c_circles={};
X=joha{kit}; %FIRST ELIPSE 
X_x=X(:,1);
X_y=X(:,2);
for iu=1:length(X)
    dist_sq = (X_x-X_x(iu)).^2+(X_y-X_y(iu)).^2;
    [dist_sq_sort, dist_sq_index]=sort(dist_sq);
     too_close=dist_sq_sort<threshold;
     toocloseindex=find(too_close);
    index=dist_sq_index(toocloseindex);
    c_circles{iu}=sort(index)';
end

FINAL=0;
indexNew=1;
while indexNew <= length(c_circles)
    FINAL=FINAL+1;
    indexNew=indexNew+length(c_circles{indexNew});
end

newCircles(kit)=FINAL;
end

end 