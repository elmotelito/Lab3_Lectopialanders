function [CMx,CMy ] = find_frame_tutor ( rgb1, rgb2)
%This function takes two images and computes the distance between them
%assuming that the images have been cropped and homographied.

I = rgb1; %imread('framedanieloriginal.jpg');
J = rgb2; %imread('framedaniel1.jpg');
VerCam=382.5; %Height of Camera 'from ground'.
HorCam=155; %Horizontal Position of Frame wrt RGBCamera.
ProfCam=335; %Depth Position of Frame wrt RGBCamera.
PitchCam=45; %Angular pitch from Kinect in Real World.
Pixmm= 0.26458333; %Conversion Factor from Pixels 2 mm.
[BW, I1]=hsvFrameMask(I);
[BW2, I2]=hsvFrameMask(J);
I1=rgb2gray(I1);
I1=imadjust(I1);
I2=rgb2gray(I2);
I2=imadjust(I2);
points1 = detectSURFFeatures(I1);
points2 = detectSURFFeatures(I2);
[f1, vpts1] = extractFeatures(I1, points1);
[f2, vpts2] = extractFeatures(I2, points2);
indexPairs = matchFeatures(f1, f2) ;
matchedPoints1 = vpts1(indexPairs(:, 1));
matchedPoints2 = vpts2(indexPairs(:, 2));
figure; ax = axes;
showMatchedFeatures(I1,I2,matchedPoints1,matchedPoints2)%'montage','Parent',ax);
title('Matched Points');
 [tform, inlierframe1, inlierframe2] = ...
     estimateGeometricTransform(matchedPoints1, matchedPoints2, 'similarity');
a=matchedPoints1;
Orig=a.Location;
Xo=Orig(:,1);
Yo=Orig(:,2);
b=matchedPoints2;
New=b.Location;
Xn=New(:,1);
Yn=New(:,2);
s=size(Xo);
xdif=zeros(1,s(1));
ydif=zeros(1,s(1));
for i=1:s(1)
    dx=Xn(i)-Xo(i);
    xdif(i)=dx;
    dy=Yn(i)-Yo(i);
    ydif(i)=dy;
end
dispx=mean(xdif);
dispy=mean(ydif);
A=mean(Xo);Ap=[A, min(Xo)];
B=mean(Yo); Bp=[B, min(Yo)];
Cxo=mean(Ap);
Cyo=mean(Bp);
CMx=Cxo+dispx;
CMy=Cyo+dispy;
% outputString = sprintf('Centroid is at x:%d pixels, y:%d pixels', [CMx CMy]);
% display(outputString);
H=sqrt(dispx^2+dispy^2);
Hmm=H*Pixmm;
M=tform.T;
angle=asin(M(1,2))*(180/pi());
Xshift=M(3,1)*Pixmm; %Horizontal Displacement in mm
ProfShift=(M(3,2)*Pixmm); %Depth Displacement in mm
HorCamNew=HorCam-Xshift;
ProfCamNew=ProfCam-ProfShift;
%Directions to get to Camera From Arbitrary Frame wrt Original Frame:
fprintf('From the closest corner, on your right: \n');
if angle>=0
    fprintf('rotate %.2f� clockwise\n',abs(angle));
else
    fprintf('rotate %.2f� counter-clockwise\n', abs(angle));
end
fprintf('Displace %.2f mm to your left\n',abs(Xshift));
fprintf('Displace %.2f mm towards the camera base \n',abs(ProfShift));
fprintf('Here is the Arbitrary Frame\n');
fprintf('To get from the Arbitrary Frame to the Camera\n');
fprintf('Move %.2f mm upwards\n',abs(VerCam));
fprintf('Displace %.2f mm alog the longest edge of the workspace\n', HorCamNew);
fprintf('Displace %.2f mm towards the tripod\n', abs(ProfCamNew));
fprintf('Rotate %.2f� upwards\n',PitchCam);
%Calculate the Position of NewFrame wrt KinectRGBCamera
hipBase= sqrt((HorCamNew^2)+(ProfCamNew^2));
HipFinal=sqrt((hipBase^2)+(VerCam^2));
fprintf('The New Frame is at %.2f mm from KinectRGB Camera\n',HipFinal);

end


