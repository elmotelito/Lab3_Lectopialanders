%% PROJECT 3
%
%perform calibration and export the camara parameters as a variable called
%camParameters

%% Initialize motor arm
loadlibrary('dynamixel.dll', 'dynamixel.h');
libfunctions('dynamixel');
DEFAULT_PORTNUM = 5;
DEFAULT_BAUDNUM = 1;
calllib('dynamixel', 'dxl_initialize', DEFAULT_PORTNUM, DEFAULT_BAUDNUM);
calllib('dynamixel','dxl_write_word',1,32,60); %%Set speed for motor 1
calllib('dynamixel','dxl_write_word',2,32,30);
calllib('dynamixel','dxl_write_word',3,32,30);
calllib('dynamixel','dxl_write_word',4,32,20);

%% Initial position
initial_position();
%get the original sorting matrix
%angles_plane=angles_plane1();
%load('angles_plane.mat');

%% TAKE A PHOTO
%WEBCAM
% cam=webcam(1);
% cam.Resolution='1280x720';
I=snapshot(cam);
figure();imshow(I)
imwrite(I,'joha1Lib.jpg');%WEBCAM


%% DETECTION
%Matrix containing the data that has to be sent to the motors
%This matrix is 4xNumOfDominosFound where
% data = [NumCircles motor1_steps distance(cm) endEffec_steps]
data = dominoDetectionRecognition2(I,cameraParams);
%close all

%% AT THIS POINT we have a matrix containing all the found dominos, 
%(expected number=15)

dominoNum=1;
while dominoNum <= length(data)

   %% HANDLE THE PROGRAM WHEN THERE IS ONE DOMINO LEFT IN THE WORKSPACE
   if length(data) == 3
       lastDomino=data(3,:);
       assignin('base','last_Domino',lastDomino)
    %%
    %MOVE ARM TO INITIAL POSITION AND WAIT UNTIL THE USER DECIDES IF HE/SHE
    %WANTS TO CONTINUE
    initial_position();
    
%     %% ASK THE USER IF HE/SHE WANTS TO CONTINUE
%      ButtonName = questdlg('Do you want to continue?', ...
%                          'Color Question', ...
%                          'Yes', 'No','Yes');
%      switch ButtonName,
%         case 'Yes',
%            disp('Your favorite color is Red');
%              %Take a new photo
%            I=snapshot(cam);
%            figure();imshow(I)
%            %imwrite(I,'joha1Lib.jpg');
%             %Run detection
%            data = dominoDetectionRecognition2(I,cameraParams);
%            close all
%         case 'No',
%             disp('THANKS');
%             break;
%      end
   end
   
 %%
    if mod(dominoNum,3)== 0
        %bring arm to initial position
        initial_position();
        pause(5); %WAIT FOR THE ARM TO BE IN PLACE AND THEN TAKE A PHOTO
    
       %Take a new photo WHEN 2 dominos have been moved and perform detection again
       I=snapshot(cam);
       figure();imshow(I)
       imwrite(I,'joha1Lib.jpg');
       data = dominoDetectionRecognition2(I,cameraParams);
       dominoNum=1;
       %close all
   end
   
%% ROBOT ARM (PICK DOMINO AND SORTED IN THE RIGHT POSITION)
    %pick domino
    % pick_domino(angle,distance,rotation);
    [nuevo1,beta,theta_total] = pick_domino(data(dominoNum,2),data(dominoNum,3),data(dominoNum,4));
    %end_effector(data(ii,2));
    
    %WAIT!!!!!
    pause(5);
    
    %% Move to initial position
    bring_domino(data(dominoNum,3),height,beta,data(dominoNum,2),theta_total);
    
    %% Move to sorting position
    angles_circles(data(dominoNum,1),angles_plane);
   
    %%
    dominoNum=dominoNum+1;
    
    %%
    calllib('dynamixel','dxl_terminate');
end
 
%end
%end  %This is the end of the infite loop 