function [] = radius3(angle3)
%Radius 1 (Inner)
M2_r1=315;
M3_r1=661;
%%For radius 3
M2_r3=394;  %%387 originally 
M3_r3=405;  %415 originally
calllib('dynamixel','dxl_write_word',1,32,80);
calllib('dynamixel','dxl_write_word',1,30,angle3);
pause(1)
calllib('dynamixel','dxl_write_word',1,32,60);
calllib('dynamixel','dxl_write_word',3,32,40);
calllib('dynamixel','dxl_write_word',2,32,40);
radius3_move=calllib('dynamixel','dxl_read_word',1,38);
    while radius3_move ~= 0
    radius3_move=calllib('dynamixel','dxl_read_word',1,38);
    end
    pause(1)
    calllib('dynamixel','dxl_write_word',3,30,635) %% NOTA anadi esto 
    pause(1)
    calllib('dynamixel','dxl_write_word',4,30,1730);
    rot = calllib('dynamixel','dxl_read_word',4,38);
    pause(1)
    while rot ~= 0
        rot=calllib('dynamixel','dxl_read_word',4,38);
    end
    pause(0.4)
    calllib('dynamixel','dxl_write_word',4,30,2030);
    pause(1)
    
while M2_r1 < 387 && M3_r1 > 415
    M2_r1 =  M2_r1 + 2;
    M3_r1 = M3_r1 - 7;    
        calllib('dynamixel','dxl_write_word',3,30,M3_r1);
    calllib('dynamixel','dxl_write_word',2,30,M2_r1); 

end

calllib('dynamixel','dxl_write_word',1,32,55);
end 
