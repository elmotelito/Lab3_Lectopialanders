function [ I1 ]=undistort_homo_crop (rgb1, cam)
% UNDISTORT
im1 = undistortImage(rgb1, cam);
%figure();imshow(im1);

%Homography
homo_im_last=homograph_v2(im1);
%figure();imshow(homo_im_last);

%Define cropped image for analysis
I1 = imcrop(homo_im_last,[460 390 1000 500]);
figure();imshow(I1);

end