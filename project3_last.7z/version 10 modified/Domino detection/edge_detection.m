function [ yu ] = edge_detection( rgb_croppedImage )
%This function will detect the edges from a cropped image and return a gray
%image where the edges are very sharp

%Example
%   im_edges=edge_detection(rgb_image);
%   imshow(im_edges);

% clear all;

I = rgb_croppedImage;
I = immultiply(I,0.7);
I = rgb2gray(I);
I = imadjust(I,[0;0.9]);

% I = imadjust(I);
% I = imadjust(I);
I = imsharpen(I);
yu=(1-edge(I,'canny',0.1));
yu = imgaussfilt(yu,1);
yu=imadjust(yu);
yu=imadjust(yu);
yu=imadjust(yu);
%yu = adapthisteq(yu,'clipLimit',0.01,'Distribution','uniform');
yu = imsharpen(yu);
yu = imsharpen(yu);
yu = imsharpen(yu);
yu = imsharpen(yu);
yu = imsharpen(yu);
%yu = im2bw(yu);

se = strel('rectangle',[2 2]);
yu=imerode(yu,se);
% yu=imdilate(yu,se);

%imshow(yu);

end

