%-------------  TRACKING  ------------------------

%% Acquire a video from the aquisition toolbox

%% Get the video from a defined folder called 'videoPhotos'

addpath('video')
%source='C:\Users\USUARIO\Documents\University of Queensland\METR4202\videoPhotos\video.avi';
vidobj=VideoReader('input.avi');
frames=vidobj.NumberOfFrames;

%Create a folder and add it to the path
mkdir('videoPhotos1')
addpath('videoPhotos1')

%Acquire frames from the video
for i=1:frames
    camImage = read(vidobj,i); %Takes a picture
    b=sprintf('vidImage%d.png', i);
    imwrite(camImage,b); %Create a jpg image
    movefile(b,'videoPhotos1');
    imageFileNames{i}=b;
end

%At this point all the frames from the video have been saved to a new
%folder call 'videoPhotos1'


%% Create a video file 
outputVideo = VideoWriter...
    ('C:\Users\USUARIO\Documents\University of Queensland\Domino detection\video/output.avi');
outputVideo.FrameRate = 10;   %------------25 to avoid flicker?

%Open the video file
open(outputVideo)

%% Read the frames from 'videoPhotos1' and modified them so the Intrinsics
%are taking into account and homography is applied to every frame from the
%video

%Get the camera parameters based on pictures taken previously in
%calibration, so undistortion can be performed
addpath('calibrationPhotos')
%[cam,worldPoints] = get_cam_parameters();

for ii = 1:frames
    %Read the images 
    img = imread(imageFileNames{ii});
   
    %Undistorded the image
    im_undistorted = undistortImage(img, cam);
    
    homo=homograph_v3(im_undistorted);

    %Define cropped image for analysis
    %I2 = imcrop(homo,[460 320 970 700]);
    %imwrite(im_undistorted,'undistorted.jpg');
    %I2 = im(I2);  
    writeVideo(outputVideo,homo)
end

close(outputVideo)




