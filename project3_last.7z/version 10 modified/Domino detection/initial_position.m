function [] = initial_position()
calllib('dynamixel','dxl_write_word',2,30,250);
pause(2)
calllib('dynamixel','dxl_write_word',1,30,550);
calllib('dynamixel','dxl_write_word',4,30,1012);
calllib('dynamixel','dxl_write_word',3,30,661)  ;
pause(2)
a=calllib('dynamixel','dxl_read_word',1,38);
b=calllib('dynamixel','dxl_read_word',2,38);
c=calllib('dynamixel','dxl_read_word',3,38);
while a ~= 0
    a=calllib('dynamixel','dxl_read_word',1,38);
    
end
pause(0.3)  %Starts at 200 goes to 600 (low speed to 650)
calllib('dynamixel','dxl_write_word',3,32,30);
c=calllib('dynamixel','dxl_read_word',3,38);
pause(0.2)
while c ~= 0
    c=calllib('dynamixel','dxl_read_word',3,38);
end

pause(0.3)
calllib('dynamixel','dxl_write_word',2,32,20);
calllib('dynamixel','dxl_write_word',2,30,325);
end 