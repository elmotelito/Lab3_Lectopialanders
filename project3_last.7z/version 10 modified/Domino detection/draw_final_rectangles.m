function [Xpos11,Ypos11] = draw_final_rectangles(hola2)
for i=1:length(hola2)
    Location = hola2(i).Location;
        %Axes = hola2(i).Axes;
        %DEFINE THE RECTANGLE WE WANT (i.e width and length)
        a = [140 90];
        Axes=single(a);
        Orientation(i)=hola2(i).Orientation;  
    if hola2(i).Orientation>0
        param = [Location(1), Location(2), Axes(2), Axes(1), (pi/2)-Orientation(i)]; 
    end 
    if hola2(i).Orientation<0
        if hola2(i).Orientation<1
            param = [Location(1), Location(2), Axes(2), Axes(1),-(Orientation(i)-pi/2)];
        else
            param = [Location(1), Location(2), Axes(2), Axes(1),Orientation(i)];      
        end
    end
    %imshow(I);
    
%     param(i,3)= 65;%SET width
%     param(i,4)= 135;%SET heigth
    
   % param
%      hold on
    [h,Xpos1,Ypos1]=DrawRectangle_v6(param);
    Xpos11(i,:) = Xpos1;
    Ypos11(i,:) = Ypos1;
    new_matr(i,:) = [Xpos1,Ypos1];  
% 
%      plot(hola2)
%      hold on
end
end