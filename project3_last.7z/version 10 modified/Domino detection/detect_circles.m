function [numCircles,flag,circularRegions] = detect_circles( edges_image )
%Detect the circles inside an image previously defined to contain a domino.
%Input is a gray image, which contains a domino candidate. As well as the
%color image of the scene

% Example [numCircles,flag] = detect_circles( edges_image )

%Use the color image to improve the yellow circles
rgb = edges_image(:,:,3);
rgb=cat(3, rgb,rgb,rgb);
rgb = imsharpen(rgb);
rgb = imsharpen(rgb);
% %I=imsharpen(I);
% %Edge detection
% I=edge_detection(I2);

flag=[];

I=rgb2gray(rgb);
%I=edges_image;
%I=imread('try1.jpg');

[regionsCir,mserCC] = detectMSERFeatures1(I,'RegionAreaRange',[100 200]);
% 'RegionAreaRange',[800 5000]

% Show all detected MSER Regions.
% figure
%  imshow(I)
%  hold on
% plot(regionsCir,'showPixelList',false,'showEllipses',true)
%%
% Measure the MSER region eccentricity to gauge region circularity.
stats = regionprops('table',mserCC,'Eccentricity','Centroid', 'Area','MajorAxisLength','MinorAxisLength');
%%
% Threshold eccentricity values to only keep the circular regions. (Circular regions have low eccentricity.)
eccentricityIdx = stats.Eccentricity <0.55; %55
%lines = stats.Eccentricity > 0.967 & stats.MajorAxisLength<45;
circularRegions = regionsCir(eccentricityIdx);
%linearRegions = regionsCir(lines);

% Show the circular regions.
% figure
% imshow(I)
% hold on
% plot(circularRegions,'showPixelList',false,'showEllipses',true)
% %saveas(gcf,'joha1.png')
% Show the linear regions.
% figure
% imshow(I)
% hold on
% plot(linearRegions,'showPixelList',true,'showEllipses',false)


%% CHECK HOW MANY CIRCLES ARE THERE?

numCircles =length(circularRegions);

if length(circularRegions)>0
    flag=1;
else
    flag=0;
    
end
%numLines =length(linearRegions);

%% Plot all the circles and select only one
% p=1;
% [~,ord] = sort([circularRegions.Location(:,1)]);
%     circularRegions = circularRegions(ord);
%     
% while (p<=length(circularRegions)-1)
%     
%     R = circularRegions(p).Location;
%     S = circularRegions(p+1).Location;
%     X = [R(1) R(2) S(1) S(2)];
%     
%     if ((abs(R(1)-S(1))<25) && (abs(R(2)-S(2))<25))
%         Q = circularRegions(p).Axes;
%         QQ = circularRegions(p+1).Axes;
%         if  Q(2)>QQ(2)
%             circularRegions(p+1)=[];
%         else
%             circularRegions(p)=[];
%         end
%         p=p-1;
%             
%     end
%     p=p+1;
%    %     if a==1
% %         p=p-1;
% %         a=0;
% %     end
% end
%     
% %close all
% 
% [~,ord] = sort([circularRegions.Location(:,2)]);
%     circularRegions = circularRegions(ord);
% p=1;
% while (p<=length(circularRegions)-1)
%     
%     R = circularRegions(p).Location;
%     S = circularRegions(p+1).Location;
%     X = [R(1) R(2) S(1) S(2)];
%     
%     if ((abs(R(1)-S(1))<25) && (abs(R(2)-S(2))<25))
%         Q = circularRegions(p).Axes;
%         QQ = circularRegions(p+1).Axes;
%         if  Q(2)>QQ(2)
%             circularRegions(p+1)=[];
%         else
%             circularRegions(p)=[];
%         end
%         p=p-1;
%             
%     end
%     p=p+1;
%    %     if a==1
% %         p=p-1;
% %         a=0;
% %     end
% end
% 

% length(circularRegions)
% field1 = 'Circles'; value1 = {circularRegions};
% field2 = 'Lines'; value2 = {linearRegions};
% domino = struct(field1,value1,field2,value2)

% figure
% imshow(I)
% hold on
% plot(circularRegions,'showPixelList',false,'showEllipses',true)



end

