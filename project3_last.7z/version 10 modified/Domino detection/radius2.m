function [] = radius2(angle2)
calllib('dynamixel','dxl_write_word',1,32,80);
calllib('dynamixel','dxl_write_word',3,32,40);
calllib('dynamixel','dxl_write_word',2,32,40);
%Radius 1 (Inner)
M2_r1=315;
M3_r1=661;
%%Radius 2
M2_r2=365; %%350 originally
M3_r2=520; %% 536 originally 
calllib('dynamixel','dxl_write_word',1,30,angle2);
pause(0.8)
radius3_move=calllib('dynamixel','dxl_read_word',1,38);
    while radius3_move ~= 0
    radius3_move=calllib('dynamixel','dxl_read_word',1,38);
    end
    pause(1)
  calllib('dynamixel','dxl_write_word',3,30,635) %% NOTA anadi esto 
    pause(1)
    calllib('dynamixel','dxl_write_word',4,30,1730);
    rot = calllib('dynamixel','dxl_read_word',4,38);
    pause(1)
    while rot ~= 0
        rot=calllib('dynamixel','dxl_read_word',4,38);
    end
    calllib('dynamixel','dxl_write_word',4,30,2030);
    pause(0.8)
    
while M2_r1 < 355 && M3_r1 > 520
    M2_r1 =  M2_r1 + 2;
    M3_r1 = M3_r1 - 7;    
        calllib('dynamixel','dxl_write_word',3,30,M3_r1);
    calllib('dynamixel','dxl_write_word',2,30,M2_r1); 

end
calllib('dynamixel','dxl_write_word',1,32,55);
end 